<?php
if (!defined('IN_SCRIPT')) {
    die('Invalid attempt');
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>

<div style="text-align:center;font-size:larger;font-weight:bold;"><?php echo $lang['t06']; ?><br class="clear" />
<a href="gbook.php?a=sign"><?php echo $lang['t48']; ?></a></div>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

